﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MvcApplication2.Models
{
    class TestDataClass1
    {
        static public string strMail = ""+
"\n<MYMAIL>" +
"\n<HEADER>" +
"\nFrom: jimmy@joeschedule.mailgun.org" +
"\nTo: Frank Mastronardi <mastronardif@gmail.com>" +
"\nSubject: dancer bee joemailweb" +
"\nIn-Reply-To: <CAAAKxgKEqWkQ_v3kPRhY+3ATgM1ePYcCLtv+-1qtT3T=s=AYsAmail.gmail.com>" +
"\nReferences: <CAAAKxgKEqWkQ_v3kPRhY+3ATgM1ePYcCLtv+-1qtT3T=s=AYsAmail.gmail.com>" +
"\nMessage-Id: <FU uddy mailbox-19950-1311902078-753076ww3.pairlite.com>" +
"\nDate: Thu, 13 Oct 2011 21:14:38 -0400" +
"\nMIME-Version: 1.0" +
"Content-Type: text/html; charset=\"UTF-8\"" +
"\n" +
"\n</HEADER>" +
"\n" +
"\n<tags>" +
"\n'$tagValue'" +
"\n</tags>" +
"\n" +
"\n</MYMAIL>" +
"\n"; 

        static public string strTestJson = ""+
"{                            "+
"  \"root_wb_pf\": {          " +  
"    \"name\": \"bobo\",      "+
"    \"CELL\": [              "+  
"      {                      "+
"        \"Cell\": \"1\",     "+  
"        \"Row\": \"1\",      "+
"        \"Value\": \"123.123\""+
"      },                      "+
"      {                       "+
"        \"Cell\": \"2\",      "+
"        \"Row\": \"1\",       "+
"        \"Value\": \"123.123\""+
"      },                      "+
"      {                       "+
"        \"Cell\": \"3\",       "+
"        \"Row\": \"1\",        "+
"        \"Value\": \"123.123\" "+
"      },                       "+
"      {                        "+
"        \"Cell\": \"1\",       "+
"        \"Row\": \"2\",        "+
"        \"Value\": \"123.123\" "+
"      },                       "+
"      {                        "+
"        \"Cell\": \"2\",       "+
"        \"Row\": \"2\",        "+
"        \"Value\": \"123.123\" "+
"      },                       "+
"      {                        "+
"        \"Cell\": \"3\",       "+
"        \"Row\": \"2\",        "+
"        \"Value\": \"123.123\" "+
"      },                       "+
"      {                        "+
"        \"Cell\": \"1\",       "+
"        \"Row\": \"3\",        "+
"        \"Value\": \"123.123\" "+
"      },                       "+
"      {                        "+
"        \"Cell\": \"2\",       "+
"        \"Row\": \"3\",        "+
"        \"Value\": \"123.123\" "+
"      },                       "+
"      {                        "+
"        \"Cell\": \"3\",       "+
"        \"Row\": \"3\",        "+
"        \"Value\": \"13.123\"  "+
"      }                        "+
"    ]                          "+
"  }                            "+
"}";                            
                                
    }                           
}                               
