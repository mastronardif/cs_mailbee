﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using mymail;
using myrabbitmq;
using RabbitMQ.Models;
using System.Configuration;


namespace RabbitMQ.Business
{

    public class busMail
    {
        static class myRabbitMQVitals
        {
            public static string _emailRoot = ConfigurationManager.AppSettings["EmailRoot"];
        }

        static public string sendToGmail(string tag)
        {
            string retval = MyMail.prepForGmail(tag);
            return publish(retval);
        }

        static public string popOne()
        {
            // pop a message from the queue.
            string retval = MyRabbotMQ.Pop();
            
            // Parse the data for vitals.
            string to = "mastronardif@gmail.com";
            // Does it pass the whitelist

            // get http data
            //Uri url = new System.Uri("http://www.yahoo.com/"); //        http://slashdot.org");
            //Uri url = new System.Uri("http://nytimes.com");
            //Uri url = new System.Uri("http://joeschedule.com");
            Uri url = new System.Uri("http://drudgereport.com");
            retval = MyBrowser.GetResponse(url);

            //MyBrowser.normalize http:// to mailto
            // Noramlise the a href to email, and reomve images if requested.
            retval = MyBrowser.NormalizeHttpToEmail(url.AbsoluteUri, retval, myRabbitMQVitals._emailRoot);
            //Program._log.Debug(retval);
            // merge

            // mail to _____
            
            string from = myRabbitMQVitals._emailRoot; // "mastronardif@gmail.com";
            //retval = mymail.MyMail.SendByMG22Gino(to, from, retval);
            retval = mymail.MyMail.SendByMG22(to, from, retval);
           //retval = mymail.MyMail.SendByMG(retval);


            return retval;
        }


        static public string publish(string tag)
        {
            string retval = MyRabbotMQ.Publish(tag);
            return retval;
        }
    }
}